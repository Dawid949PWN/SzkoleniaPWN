package controller;

public class AdminController {
}
